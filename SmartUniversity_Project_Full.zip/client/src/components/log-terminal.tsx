import { ScrollArea } from "@/components/ui/scroll-area";
import { useUniversity } from "@/lib/university-context";
import { cn } from "@/lib/utils";
import { Terminal } from "lucide-react";
import { useEffect, useRef } from "react";

export function LogTerminal() {
  const { logs } = useUniversity();
  // const scrollRef = useRef<HTMLDivElement>(null);

  // useEffect(() => {
  //   if (scrollRef.current) {
  //     scrollRef.current.scrollTop = 0;
  //   }
  // }, [logs]);

  return (
    <div className="flex flex-col h-full border rounded-lg bg-black text-green-400 font-mono text-sm shadow-inner overflow-hidden">
      <div className="flex items-center px-4 py-2 bg-neutral-900 border-b border-neutral-800">
        <Terminal className="w-4 h-4 mr-2" />
        <span className="font-bold">System Output (CLI)</span>
      </div>
      <ScrollArea className="flex-1 p-4 h-[200px]">
        <div className="space-y-1">
          {logs.length === 0 && (
            <div className="text-neutral-500 italic">
              Ready. Waiting for commands...
            </div>
          )}
          {logs.map((log) => (
            <div key={log.id} className="flex items-start gap-2">
              <span className="text-neutral-500 shrink-0">
                [{log.timestamp.toLocaleTimeString()}]
              </span>
              <span
                className={cn(
                  "break-words",
                  log.type === "error" && "text-red-500 font-bold",
                  log.type === "success" && "text-green-400",
                  log.type === "warning" && "text-yellow-400",
                  log.type === "info" && "text-blue-300"
                )}
              >
                {log.type === "error" ? "Error: " : ""}
                {log.message}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
