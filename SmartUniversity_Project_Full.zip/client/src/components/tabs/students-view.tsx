import { useState } from "react";
import { useUniversity } from "@/lib/university-context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, UserPlus } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function StudentsView() {
  const { university, addLog, refresh } = useUniversity();
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [major, setMajor] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const numId = parseInt(id);
      if (isNaN(numId)) throw new Error("ID must be a number");
      
      university.addStudent(numId, name, major);
      addLog("success", `Added student: ${name} (${id})`);
      refresh();
      
      // Reset form
      setId("");
      setName("");
      setMajor("");
    } catch (err: any) {
      setError(err.message);
      addLog("error", err.message);
    }
  };

  const students = Array.from(university.students.values());

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Add Student
            </CardTitle>
            <CardDescription>
              Register a new student into the system. ID must be unique.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddStudent} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="student-id">Student ID</Label>
                <Input
                  id="student-id"
                  placeholder="e.g. 1001"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                  data-testid="input-student-id"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="student-name">Full Name</Label>
                <Input
                  id="student-name"
                  placeholder="e.g. Alice Johnson"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  data-testid="input-student-name"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="student-major">Major</Label>
                <Input
                  id="student-major"
                  placeholder="e.g. Computer Science"
                  value={major}
                  onChange={(e) => setMajor(e.target.value)}
                  data-testid="input-student-major"
                />
              </div>
              
              <Button type="submit" className="w-full" data-testid="button-add-student">
                Add Student
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="h-full flex flex-col">
          <CardHeader>
            <CardTitle>Student Directory</CardTitle>
            <CardDescription>List of all registered students ({students.length})</CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            {students.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                No students registered yet.
              </div>
            ) : (
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Major</TableHead>
                      <TableHead className="text-right">GPA</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {students.sort((a,b) => a.id - b.id).map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.id}</TableCell>
                        <TableCell>{student.name}</TableCell>
                        <TableCell>{student.major}</TableCell>
                        <TableCell className="text-right font-mono">
                          {university.computeGPA(student.id).toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
