import { useState } from "react";
import { useUniversity } from "@/lib/university-context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, GraduationCap, PencilRuler } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GradeUtils } from "@/lib/grade-utils";

export function EnrollmentsView() {
  const { university, addLog, refresh } = useUniversity();
  
  // Enroll State
  const [enrollStudentId, setEnrollStudentId] = useState("");
  const [enrollCourseCode, setEnrollCourseCode] = useState("");
  
  // Grade State
  const [gradeStudentId, setGradeStudentId] = useState("");
  const [gradeCourseCode, setGradeCourseCode] = useState("");
  const [gradePercent, setGradePercent] = useState("");

  const [error, setError] = useState<string | null>(null);

  const handleEnroll = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const sId = parseInt(enrollStudentId);
      if (isNaN(sId)) throw new Error("Student ID must be a number");
      
      university.enroll(sId, enrollCourseCode);
      addLog("success", `Enrolled student ${sId} in ${enrollCourseCode}`);
      refresh();
      
      // Don't clear inputs fully as users might want to enroll same student in another course
      setEnrollCourseCode("");
    } catch (err: any) {
      setError(err.message);
      addLog("error", err.message);
    }
  };

  const handleGrade = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const sId = parseInt(gradeStudentId);
      if (isNaN(sId)) throw new Error("Student ID must be a number");
      
      const percent = parseFloat(gradePercent);
      if (isNaN(percent)) throw new Error("Grade must be a number");

      university.assignGrade(sId, gradeCourseCode, percent);
      addLog("success", `Assigned grade ${percent} to student ${sId} in ${gradeCourseCode}`);
      refresh();
      
      setGradePercent("");
    } catch (err: any) {
      setError(err.message);
      addLog("error", err.message);
    }
  };

  const students = Array.from(university.students.values());
  const courses = Array.from(university.courses.values());
  const enrollments = university.enrollments;

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-6">
        {/* Enroll Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5" />
              Enroll Student
            </CardTitle>
            <CardDescription>
              Register a student for a course.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleEnroll} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="enroll-student">Student</Label>
                  <select 
                    id="enroll-student"
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                    value={enrollStudentId}
                    onChange={(e) => setEnrollStudentId(e.target.value)}
                  >
                    <option value="">Select Student</option>
                    {students.map(s => (
                      <option key={s.id} value={s.id}>{s.id} - {s.name}</option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="enroll-course">Course</Label>
                  <select 
                    id="enroll-course"
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                    value={enrollCourseCode}
                    onChange={(e) => setEnrollCourseCode(e.target.value)}
                  >
                    <option value="">Select Course</option>
                    {courses.map(c => (
                      <option key={c.code} value={c.code}>{c.code} - {c.title}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <Button type="submit" className="w-full" disabled={!enrollStudentId || !enrollCourseCode}>
                Enroll
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Grade Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PencilRuler className="h-5 w-5" />
              Assign Grade
            </CardTitle>
            <CardDescription>
              Record a grade (0-100) for an enrollment.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGrade} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="grade-student">Student</Label>
                  <select 
                    id="grade-student"
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                    value={gradeStudentId}
                    onChange={(e) => setGradeStudentId(e.target.value)}
                  >
                    <option value="">Select Student</option>
                    {students.map(s => (
                      <option key={s.id} value={s.id}>{s.id} - {s.name}</option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="grade-course">Course</Label>
                  <select 
                    id="grade-course"
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                    value={gradeCourseCode}
                    onChange={(e) => setGradeCourseCode(e.target.value)}
                  >
                    <option value="">Select Course</option>
                    {courses.map(c => (
                      <option key={c.code} value={c.code}>{c.code} - {c.title}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="grade-percent">Grade (0-100)</Label>
                <Input
                  id="grade-percent"
                  type="number"
                  placeholder="e.g. 85"
                  value={gradePercent}
                  onChange={(e) => setGradePercent(e.target.value)}
                  min="0"
                  max="100"
                  step="0.1"
                />
              </div>
              
              <Button type="submit" variant="secondary" className="w-full" disabled={!gradeStudentId || !gradeCourseCode || !gradePercent}>
                Assign Grade
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="h-full flex flex-col">
          <CardHeader>
            <CardTitle>Enrollment Records</CardTitle>
            <CardDescription>List of all active enrollments ({enrollments.length})</CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            {enrollments.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                No enrollments yet.
              </div>
            ) : (
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Course</TableHead>
                      <TableHead className="text-right">Grade</TableHead>
                      <TableHead className="text-right">Point</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {enrollments.map((enrollment, idx) => {
                      const student = university.students.get(enrollment.studentId);
                      const course = university.courses.get(enrollment.courseCode);
                      return (
                        <TableRow key={`${enrollment.studentId}-${enrollment.courseCode}`}>
                          <TableCell>
                            <div className="font-medium">{student?.name}</div>
                            <div className="text-xs text-muted-foreground">{student?.id}</div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{course?.title}</div>
                            <div className="text-xs text-muted-foreground">{course?.code}</div>
                          </TableCell>
                          <TableCell className="text-right">
                            {enrollment.gradePercent !== null ? enrollment.gradePercent : "-"}
                          </TableCell>
                          <TableCell className="text-right font-mono text-muted-foreground">
                            {enrollment.gradePercent !== null 
                              ? GradeUtils.toGradePoint(enrollment.gradePercent).toFixed(1) 
                              : "-"}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
