import { useState } from "react";
import { useUniversity } from "@/lib/university-context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, BookOpen } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function CoursesView() {
  const { university, addLog, refresh } = useUniversity();
  const [code, setCode] = useState("");
  const [title, setTitle] = useState("");
  const [credits, setCredits] = useState("");
  const [instructor, setInstructor] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const numCredits = parseInt(credits);
      if (isNaN(numCredits)) throw new Error("Credits must be a number");
      
      university.addCourse(code, title, numCredits, instructor);
      addLog("success", `Added course: ${code} - ${title}`);
      refresh();
      
      // Reset form
      setCode("");
      setTitle("");
      setCredits("");
      setInstructor("");
    } catch (err: any) {
      setError(err.message);
      addLog("error", err.message);
    }
  };

  const courses = Array.from(university.courses.values());

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Add Course
            </CardTitle>
            <CardDescription>
              Create a new course. Code must be unique.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddCourse} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="course-code">Course Code</Label>
                  <Input
                    id="course-code"
                    placeholder="e.g. CS101"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    data-testid="input-course-code"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="course-credits">Credits</Label>
                  <Input
                    id="course-credits"
                    type="number"
                    placeholder="e.g. 4"
                    value={credits}
                    onChange={(e) => setCredits(e.target.value)}
                    data-testid="input-course-credits"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="course-title">Course Title</Label>
                <Input
                  id="course-title"
                  placeholder="e.g. Intro to Programming"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  data-testid="input-course-title"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="course-instructor">Instructor</Label>
                <Input
                  id="course-instructor"
                  placeholder="e.g. Dr. Smith"
                  value={instructor}
                  onChange={(e) => setInstructor(e.target.value)}
                  data-testid="input-course-instructor"
                />
              </div>
              
              <Button type="submit" className="w-full" data-testid="button-add-course">
                Add Course
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="h-full flex flex-col">
          <CardHeader>
            <CardTitle>Course Catalog</CardTitle>
            <CardDescription>List of all available courses ({courses.length})</CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            {courses.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                No courses added yet.
              </div>
            ) : (
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Code</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Credits</TableHead>
                      <TableHead>Instructor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {courses.sort((a,b) => a.code.localeCompare(b.code)).map((course) => (
                      <TableRow key={course.code}>
                        <TableCell className="font-medium">{course.code}</TableCell>
                        <TableCell>{course.title}</TableCell>
                        <TableCell>{course.credits}</TableCell>
                        <TableCell>{course.instructor}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
