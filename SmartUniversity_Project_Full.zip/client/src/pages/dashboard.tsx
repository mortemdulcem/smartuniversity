import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UniversityProvider, useUniversity } from "@/lib/university-context";
import { LogTerminal } from "@/components/log-terminal";
import { StudentsView } from "@/components/tabs/students-view";
import { CoursesView } from "@/components/tabs/courses-view";
import { EnrollmentsView } from "@/components/tabs/enrollments-view";
import { Download, GraduationCap, School, Upload, FileCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useRef } from "react";

function DashboardContent() {
  const { downloadData, loadData, university } = useUniversity();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      loadData(e.target.files);
      // Reset input
      e.target.value = "";
    }
  };

  const handleDownloadSource = () => {
    // Create a link and click it programmatically
    const link = document.createElement('a');
    link.href = '/downloads/SmartUniversity_Project.zip';
    link.download = 'SmartUniversity_Project.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-12">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-10">
        <div className="container mx-auto py-4 px-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 text-white p-2 rounded-lg shadow-lg shadow-blue-500/20">
              <School className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white leading-none">
                Smart University
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                Academic Management System
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <input 
              type="file" 
              multiple 
              accept=".csv" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileChange}
            />
             <Button variant="secondary" onClick={handleDownloadSource} className="hidden sm:flex gap-2 bg-green-100 text-green-800 hover:bg-green-200 border-green-200">
              <FileCode className="h-4 w-4" />
              Download Project Files
            </Button>
            <Button variant="outline" onClick={handleUploadClick} className="hidden sm:flex gap-2">
              <Upload className="h-4 w-4" />
              Load CSV
            </Button>
            <Button variant="outline" onClick={downloadData} className="hidden sm:flex gap-2">
              <Download className="h-4 w-4" />
              Save CSV
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 space-y-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Controls */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="students" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6 h-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1 shadow-sm">
                <TabsTrigger value="students" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 data-[state=active]:shadow-none">Students</TabsTrigger>
                <TabsTrigger value="courses" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 data-[state=active]:shadow-none">Courses</TabsTrigger>
                <TabsTrigger value="enrollments" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 data-[state=active]:shadow-none">Enrollment & Grading</TabsTrigger>
              </TabsList>
              
              <TabsContent value="students" className="mt-0 focus-visible:ring-0">
                <StudentsView />
              </TabsContent>
              
              <TabsContent value="courses" className="mt-0 focus-visible:ring-0">
                <CoursesView />
              </TabsContent>
              
              <TabsContent value="enrollments" className="mt-0 focus-visible:ring-0">
                <EnrollmentsView />
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Column: Stats & Logs */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">System Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold">{university.students.size}</div>
                    <div className="text-xs text-muted-foreground">Students</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{university.courses.size}</div>
                    <div className="text-xs text-muted-foreground">Courses</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{university.enrollments.length}</div>
                    <div className="text-xs text-muted-foreground">Enrollments</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Log Terminal */}
            <LogTerminal />

            <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-100 dark:border-blue-900">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <GraduationCap className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800 dark:text-blue-200">
                    <p className="font-semibold mb-1">Academic Rules</p>
                    <ul className="list-disc pl-4 space-y-1 opacity-80">
                      <li>GPA uses 4.0 scale (Weighted)</li>
                      <li>Grades: 90-100 (4.0), 85-89.9 (3.7)...</li>
                      <li>CSV export available via button</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

export default function Dashboard() {
  return (
    <UniversityProvider>
      <DashboardContent />
    </UniversityProvider>
  );
}
