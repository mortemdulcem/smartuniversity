/**
 * GradeUtils - Not dönüşüm utility'si
 * 90-100 -> 4.0
 * 85-89.9 -> 3.7
 * 80-84.9 -> 3.3
 * 75-79.9 -> 3.0
 * 70-74.9 -> 2.7
 * 65-69.9 -> 2.3
 * 60-64.9 -> 2.0
 * 55-59.9 -> 1.7
 * 50-54.9 -> 1.0
 * <50 -> 0.0
 */
export class GradeUtils {
  public static toGradePoint(percent: number): number {
    if (percent >= 90) return 4.0;
    if (percent >= 85) return 3.7;
    if (percent >= 80) return 3.3;
    if (percent >= 75) return 3.0;
    if (percent >= 70) return 2.7;
    if (percent >= 65) return 2.3;
    if (percent >= 60) return 2.0;
    if (percent >= 55) return 1.7;
    if (percent >= 50) return 1.0;
    return 0.0;
  }
}
