import { IStudent, ICourse, IEnrollment } from "./types";
import { GradeUtils } from "./grade-utils";

export class Student implements IStudent {
  constructor(
    public id: number,
    public name: string,
    public major: string
  ) {
    if (id <= 0) throw new Error("Student ID must be positive");
    if (!name || name.trim() === "") throw new Error("Student name cannot be blank");
    if (!major || major.trim() === "") throw new Error("Student major cannot be blank");
    this.name = name.trim();
    this.major = major.trim();
  }

  toCSV(): string {
    return `${this.id},"${this.escapeCSV(this.name)}","${this.escapeCSV(this.major)}"`;
  }

  private escapeCSV(value: string): string {
    return value.replace(/"/g, '""');
  }
}

export class Course implements ICourse {
  constructor(
    public code: string,
    public title: string,
    public credits: number,
    public instructor: string
  ) {
    if (!code || code.trim() === "") throw new Error("Course code cannot be blank");
    if (!title || title.trim() === "") throw new Error("Course title cannot be blank");
    if (credits <= 0) throw new Error("Course credits must be positive");
    if (!instructor || instructor.trim() === "") throw new Error("Instructor name cannot be blank");
    
    this.code = code.trim();
    this.title = title.trim();
    this.instructor = instructor.trim();
  }

  toCSV(): string {
    return `${this.code},"${this.escapeCSV(this.title)}",${this.credits},"${this.escapeCSV(this.instructor)}"`;
  }

  private escapeCSV(value: string): string {
    return value.replace(/"/g, '""');
  }
}

export class Enrollment implements IEnrollment {
  public gradePercent: number | null = null;

  constructor(
    public studentId: number,
    public courseCode: string
  ) {
    if (studentId <= 0) throw new Error("Student ID must be positive");
    if (!courseCode || courseCode.trim() === "") throw new Error("Course code cannot be blank");
    this.courseCode = courseCode.trim();
  }

  setGrade(grade: number) {
    if (grade < 0 || grade > 100) throw new Error("Grade must be between 0 and 100");
    this.gradePercent = grade;
  }

  toCSV(): string {
    return `${this.studentId},${this.courseCode},${this.gradePercent !== null ? this.gradePercent : ""}`;
  }
}

export class University {
  students: Map<number, Student>;
  courses: Map<string, Course>;
  enrollments: Enrollment[];

  constructor() {
    this.students = new Map();
    this.courses = new Map();
    this.enrollments = [];
  }

  addStudent(id: number, name: string, major: string) {
    if (this.students.has(id)) {
      throw new Error(`Student with ID ${id} already exists`);
    }
    const student = new Student(id, name, major);
    this.students.set(id, student);
  }

  addCourse(code: string, title: string, credits: number, instructor: string) {
    if (this.courses.has(code)) {
      throw new Error(`Course with code ${code} already exists`);
    }
    const course = new Course(code, title, credits, instructor);
    this.courses.set(code, course);
  }

  enroll(studentId: number, courseCode: string) {
    if (!this.students.has(studentId)) {
      throw new Error(`Student not found: ${studentId}`);
    }
    if (!this.courses.has(courseCode)) {
      throw new Error(`Course not found: ${courseCode}`);
    }

    const exists = this.enrollments.some(
      e => e.studentId === studentId && e.courseCode === courseCode
    );
    if (exists) {
      throw new Error(`Student ${studentId} is already enrolled in ${courseCode}`);
    }

    const enrollment = new Enrollment(studentId, courseCode);
    this.enrollments.push(enrollment);
  }

  assignGrade(studentId: number, courseCode: string, grade: number) {
    const enrollment = this.enrollments.find(
      e => e.studentId === studentId && e.courseCode === courseCode
    );
    
    if (!enrollment) {
      throw new Error(`Enrollment not found for Student ${studentId} in Course ${courseCode}`);
    }

    enrollment.setGrade(grade);
  }

  computeGPA(studentId: number): number {
    const studentEnrollments = this.enrollments.filter(
      e => e.studentId === studentId && e.gradePercent !== null
    );

    if (studentEnrollments.length === 0) return 0.0;

    let totalPoints = 0;
    let totalCredits = 0;

    for (const enrollment of studentEnrollments) {
      const course = this.courses.get(enrollment.courseCode);
      if (course && enrollment.gradePercent !== null) {
        const gradePoint = GradeUtils.toGradePoint(enrollment.gradePercent);
        totalPoints += gradePoint * course.credits;
        totalCredits += course.credits;
      }
    }

    if (totalCredits === 0) return 0.0;
    return Number((totalPoints / totalCredits).toFixed(2));
  }

  // CSV Helpers
  getStudentsCSV(): string {
    return "id,name,major\n" + Array.from(this.students.values()).map(s => s.toCSV()).join("\n");
  }

  getCoursesCSV(): string {
    return "code,title,credits,instructor\n" + Array.from(this.courses.values()).map(c => c.toCSV()).join("\n");
  }

  getEnrollmentsCSV(): string {
    return "studentId,courseCode,gradePercent\n" + this.enrollments.map(e => e.toCSV()).join("\n");
  }
}
