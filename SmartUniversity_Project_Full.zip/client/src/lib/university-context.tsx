import React, { createContext, useContext, useState, useEffect } from "react";
import { University } from "./university";
import { SystemLog, LogType } from "./types";
import { saveAs } from "file-saver";

interface UniversityContextType {
  university: University;
  logs: SystemLog[];
  addLog: (type: LogType, message: string) => void;
  refresh: () => void; // Force re-render
  downloadData: () => void;
  loadData: (files: FileList) => Promise<void>;
}

const UniversityContext = createContext<UniversityContextType | null>(null);

export function UniversityProvider({ children }: { children: React.ReactNode }) {
  const [university] = useState(() => new University());
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [version, setVersion] = useState(0); // To force re-renders on data change

  const addLog = (type: LogType, message: string) => {
    const newLog: SystemLog = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      message,
      timestamp: new Date(),
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  const refresh = () => {
    setVersion((v) => v + 1);
  };

  const downloadData = () => {
    try {
      const studentsCSV = university.getStudentsCSV();
      const coursesCSV = university.getCoursesCSV();
      const enrollmentsCSV = university.getEnrollmentsCSV();

      const blobS = new Blob([studentsCSV], { type: "text/csv;charset=utf-8" });
      saveAs(blobS, "students.csv");
      
      setTimeout(() => {
        const blobC = new Blob([coursesCSV], { type: "text/csv;charset=utf-8" });
        saveAs(blobC, "courses.csv");
      }, 500);

      setTimeout(() => {
        const blobE = new Blob([enrollmentsCSV], { type: "text/csv;charset=utf-8" });
        saveAs(blobE, "enrollments.csv");
      }, 1000);
      
      addLog("success", "Data downloaded as CSV files.");
    } catch (e) {
      addLog("error", "Failed to download data.");
    }
  };

  const loadData = async (files: FileList) => {
    try {
      let loadedCount = 0;
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const text = await file.text();
        const lines = text.split("\n").map(l => l.trim()).filter(l => l.length > 0);
        
        if (lines.length < 2) continue; // Skip empty files
        
        const header = lines[0].toLowerCase();
        
        // Simple heuristic to detect file type based on header
        if (header.includes("id") && header.includes("name") && header.includes("major")) {
          // Students
          let count = 0;
          for (let j = 1; j < lines.length; j++) {
            try {
              // Parse logic matching format: id,"name","major"
              // Simple regex parse since we generated it with quotes
              // 1001,"Alice Johnson","CS"
              const line = lines[j];
              const parts = line.match(/(\d+),"([^"]+)","([^"]+)"/);
              if (parts) {
                const id = parseInt(parts[1]);
                const name = parts[2];
                const major = parts[3];
                university.addStudent(id, name, major);
                count++;
              }
            } catch (e) {
              console.warn("Skipping malformed student line:", lines[j]);
            }
          }
          addLog("success", `Loaded ${count} students from ${file.name}`);
          loadedCount++;
        } else if (header.includes("code") && header.includes("title") && header.includes("credits")) {
          // Courses
          let count = 0;
          for (let j = 1; j < lines.length; j++) {
            try {
              // CS101,"Object-Oriented Programming",4,"Dr. Smith"
              const line = lines[j];
              const parts = line.match(/([^,]+),"([^"]+)",(\d+),"([^"]+)"/);
              if (parts) {
                const code = parts[1];
                const title = parts[2];
                const credits = parseInt(parts[3]);
                const instructor = parts[4];
                university.addCourse(code, title, credits, instructor);
                count++;
              }
            } catch (e) {
               console.warn("Skipping malformed course line:", lines[j]);
            }
          }
          addLog("success", `Loaded ${count} courses from ${file.name}`);
          loadedCount++;
        } else if (header.includes("studentid") && header.includes("coursecode")) {
          // Enrollments
          let count = 0;
          for (let j = 1; j < lines.length; j++) {
             try {
               // 1001,CS101,86.0
               const line = lines[j];
               const parts = line.split(",");
               if (parts.length >= 2) {
                 const sId = parseInt(parts[0]);
                 const cCode = parts[1];
                 const grade = parts[2] ? parseFloat(parts[2]) : null;
                 
                 try {
                    university.enroll(sId, cCode);
                    if (grade !== null && !isNaN(grade)) {
                      university.assignGrade(sId, cCode, grade);
                    }
                    count++;
                 } catch (err) {
                   // Ignore duplicates or missing refs during bulk load
                 }
               }
             } catch (e) {
                console.warn("Skipping malformed enrollment line:", lines[j]);
             }
          }
          addLog("success", `Loaded ${count} enrollments from ${file.name}`);
          loadedCount++;
        }
      }
      
      if (loadedCount > 0) {
        refresh();
      } else {
        addLog("warning", "No recognized CSV files found.");
      }
    } catch (e: any) {
      addLog("error", "Failed to load data: " + e.message);
    }
  };

  return (
    <UniversityContext.Provider value={{ university, logs, addLog, refresh, downloadData, loadData }}>
      {children}
    </UniversityContext.Provider>
  );
}

export function useUniversity() {
  const context = useContext(UniversityContext);
  if (!context) {
    throw new Error("useUniversity must be used within a UniversityProvider");
  }
  return context;
}
