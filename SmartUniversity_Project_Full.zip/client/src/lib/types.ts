export interface IStudent {
  id: number;
  name: string;
  major: string;
}

export interface ICourse {
  code: string;
  title: string;
  credits: number;
  instructor: string;
}

export interface IEnrollment {
  studentId: number;
  courseCode: string;
  gradePercent: number | null;
}

export type LogType = "info" | "success" | "error" | "warning";

export interface SystemLog {
  id: string;
  type: LogType;
  message: string;
  timestamp: Date;
}
