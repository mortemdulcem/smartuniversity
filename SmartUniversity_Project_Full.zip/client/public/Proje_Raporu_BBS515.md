# BBS 515 - Nesne Yönelimli Programlama Proje Raporu
**Konu:** Smart University Yönetim Sistemi Tasarımı ve Uygulaması  
**Teslim Tarihi:** 24 Kasım 2025  

## 1. Projenin Tanımı ve Amacı
Bu proje kapsamında, bir üniversitenin temel akademik süreçlerini (öğrenci kaydı, ders açma, ders atama ve notlandırma) dijital ortamda yönetecek "Smart University" sistemi tasarlanmış ve geliştirilmiştir. Projenin temel hedefi; verilen teknik spesifikasyonlara (Domain Model) birebir sadık kalarak, veri bütünlüğünü koruyan, hataya dayanıklı (robust) ve kullanıcı dostu bir sistem mimarisi oluşturmaktır.

Geliştirilen sistemde, Nesne Yönelimli Programlama (OOP) prensiplerinden özellikle "Kapsülleme" (Encapsulation) ve "Sorumlulukların Ayrılması" (Separation of Concerns) ilkeleri merkeze alınmıştır. İstenildiği üzere, sistemde "Kalıtım" (Inheritance) mekanizması kullanılmamış, bunun yerine sınıflar arası "Kompozisyon" (Composition) ilişkisi tercih edilmiştir.

## 2. Sistem Mimarisi ve Tasarım Kararları

### 2.1. Sınıf Tasarımı ve Kapsülleme
Sistem, her biri tek bir sorumluluğa sahip (Single Responsibility Principle) dört ana sınıf üzerine inşa edilmiştir. Veri güvenliği açısından tüm sınıf değişkenleri (fields) dış dünyadan izole edilmiş (`private`) ve erişimler kontrollü metotlar üzerinden sağlanmıştır.

1.  **Student (Öğrenci) Sınıfı:**
    *   Sistemin en temel yapı taşıdır.
    *   **Validasyon:** Nesne oluşturulurken (Constructor aşamasında) ID'nin pozitif olması, isim ve bölüm bilgilerinin boş olmaması gibi kontroller yapılarak "geçersiz (invalid) nesne" oluşumu daha en baştan engellenmiştir.
    
2.  **Course (Ders) Sınıfı:**
    *   Ders bilgilerini tutar. Ders kodu (Code) birincil anahtar (primary key) olarak kabul edilmiştir.
    *   Kredilerin pozitif sayı olması zorunluluğu kod seviyesinde güvence altına alınmıştır.

3.  **Enrollment (Kayıt) Sınıfı:**
    *   Bu sınıf, bir öğrenci ile bir ders arasındaki ilişkiyi temsil eder.
    *   **Not Sistemi:** Bir öğrenci derse ilk kaydolduğunda not bilgisi belirsizdir (`null`). Sistem, not girilmemiş dersleri GPA hesaplamasına dahil etmeyecek şekilde programlanmıştır. Bu ayrım, başarısız (0) ile girilmemiş (null) not arasındaki farkı korumak adına kritik bir tasarım kararıdır.

4.  **University (Yönetim) Sınıfı:**
    *   Tüm sistemin orkestrasyonunu sağlar.
    *   **Veri Yapısı Tercihi:** Öğrenci ve ders verilerini saklamak için `List` yerine `Map` (HashMap) veri yapısı tercih edilmiştir. Bunun sebebi, öğrenci ID'si veya ders kodu bilindiğinde ilgili kayda erişim süresini O(n)'den O(1)'e (sabit zaman) düşürmektir. Bu sayede sistem performansı, veri sayısı artsa bile korunmaktadır.

### 2.2. Yardımcı Sınıflar
*   **GradeUtils:** Not dönüşüm işlemleri (100'lük sistemden 4.0'lık sisteme geçiş) ana sınıfların içine gömülmek yerine, statik metotlar içeren bu yardımcı sınıfa delege edilmiştir. Bu sayede not skalasında yapılacak olası bir değişiklik, sadece tek bir noktadan yönetilebilir hale gelmiştir.

## 3. Algoritmik Detaylar

### 3.1. Ağırlıklı GPA Hesaplama
GPA hesaplamasında basit aritmetik ortalama yerine, derslerin kredilerini baz alan "Ağırlıklı Ortalama" yöntemi uygulanmıştır.
*   *Formül:* `Toplam (Not Puanı x Ders Kredisi) / Toplam Kredi`
*   Döngü içerisinde sadece notu girilmiş (`grade != null`) dersler işleme alınmış, böylece öğrencinin henüz tamamlamadığı dersler ortalamasını düşürmemiştir.

### 3.2. CSV Veri Yönetimi (Persistence)
Verilerin kalıcılığını sağlamak adına CSV (Comma-Separated Values) formatı kullanılmıştır. Bu aşamada karşılaşılan en büyük teknik zorluk, metin alanları (örneğin ders adı) içerisinde virgül (`,`) karakterinin bulunma ihtimalidir.
*   **Çözüm:** CSV standartlarına (RFC 4180) uygun olarak, metin alanları çift tırnak (`"`) içine alınmış ve içerideki tırnak karakterleri escape edilmiştir. Bu sayede veri bütünlüğü bozulmadan dosya okuma/yazma işlemleri gerçekleştirilebilmiştir.

## 4. Proje Gereksinimlerine Uygunluk Analizi

| Gereksinim | Durum | Açıklama |
| :--- | :---: | :--- |
| **Encapsulation** | ✅ Tam | Tüm alanlar private, getter/setter yapısı kurulu. |
| **No Inheritance** | ✅ Tam | `extends` kullanılmadı, tamamen kompozisyon mimarisi. |
| **GPA Logic** | ✅ Tam | 4.0 skalası ve kredi ağırlıklı hesaplama hatasız. |
| **Input Validation** | ✅ Tam | Constructor'larda null/boş/negatif değer kontrolleri mevcut. |
| **CSV I/O** | ✅ Tam | Hatalı satırları (malformed lines) atlayan robust yapı. |

## 5. Sonuç ve Kişisel Değerlendirme
Bu proje sürecinde, sadece kod yazmanın ötesinde, bir yazılım mimarisi kurmanın ve veri bütünlüğünü korumanın önemini deneyimledim. Özellikle hatalı veri girişlerine karşı geliştirdiğim savunmacı programlama (defensive programming) teknikleri, sistemin kararlılığını artırdı. Adnan Hoca'nın belirlediği kısıtlamalar (özellikle kalıtım yasağı), beni daha modüler ve bağımsız sınıflar tasarlamaya yöneltti, bu da projenin bakımını (maintainability) kolaylaştırdı.

Sistem şu an verilen tüm test senaryolarını başarıyla geçmekte ve beklenen çıktıları üretmektedir.
